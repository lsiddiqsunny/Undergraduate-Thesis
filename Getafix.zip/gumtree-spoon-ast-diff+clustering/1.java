Class A{
/**
	 * Shows page contained in the given page record in this view. The page
	 * record must be one from this pagebook view.
	 * <p>
	 * The <code>PageBookView</code> implementation of this method asks the pagebook control to show the given page's control, and records that the given page is now current. Subclasses may extend.
	 * </p>
	 *
	 * @param pageRec
	 *            the page record containing the page to show
	 */
protected void showOutlinePageRec(OutlinePageRec pageRec) {
    // If already showing do nothing
    if (activeRec == pageRec) {
        return;
    }
    // If the page is the same, just set activeRec to pageRec
    if (activeRec != null && pageRec != null && activeRec.contentOutlinePage == pageRec.contentOutlinePage) {
        activeRec = pageRec;
        return;
    }
    activeRec = pageRec;
    Control pageControl = activeRec.contentOutlinePage.getControl();
    if (pageControl != null && !pageControl.isDisposed()) {
        PageSite pageSite = (PageSite) activeRec.getPageSite();
        // Verify that the page control is not disposed
        // If we are closing, it may have already been disposed
        sashEditorPageBook.showPage(pageControl);
        getSite().setActivePageSite(pageSite);
    }
}
}