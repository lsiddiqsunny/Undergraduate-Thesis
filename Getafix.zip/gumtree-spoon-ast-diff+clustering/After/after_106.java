class Dummy{
@Override
public boolean remove(int id) throws SQLException {
    PreparedStatement pstmt = conn.prepareStatement("delete from mensagem where id = '" + id + "'");
    int vrf = pstmt.executeUpdate();
    return vrf > 0;
}}

